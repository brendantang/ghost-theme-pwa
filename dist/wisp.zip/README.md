boilerplate for a ghost theme
